﻿namespace DefiningClasses
{
    internal class StartUp
    {
        static void Main()
        {
            
        }
    }
}