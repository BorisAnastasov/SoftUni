﻿namespace GenericArrayCreator
{
    internal class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}