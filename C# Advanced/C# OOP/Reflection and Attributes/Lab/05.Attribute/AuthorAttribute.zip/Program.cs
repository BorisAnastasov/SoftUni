﻿using System;
using System.Linq;
using System.Reflection;

namespace AuthorProblem
{
    [Author("Victor")]
    class StartUp
    {
        [Author("George")]
        static void Main(string[] args)
        {

        }
    }
}