﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using T04.Wild_Farm.Models.Interfaces;

namespace T04.Wild_Farm.Models
{
    public class Fruit : Food
    {
        public Fruit(int quantity) : base(quantity)
        {
        }
    }
}
