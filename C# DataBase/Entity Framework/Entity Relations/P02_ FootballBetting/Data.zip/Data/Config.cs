﻿namespace P02_FootballBetting.Data;

public class Config
{
       public const string connection_string 
                     = @"Server=(localdb)\\MSSQLLocalDB;Database=StudentSystem;Integrated Security=True;Encrypt=False;";
}

