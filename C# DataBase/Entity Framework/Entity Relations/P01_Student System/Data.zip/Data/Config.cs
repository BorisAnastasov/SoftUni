﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P01_StudentSystem.Data;

public class Config
{
       public const string connection_string 
                     = @"Server=(localdb)\\MSSQLLocalDB;Database=StudentSystem;Integrated Security=True;Encrypt=False;";
}

